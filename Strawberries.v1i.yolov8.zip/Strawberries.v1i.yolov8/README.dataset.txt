# Strawberries > 2023-04-25 10:07am
https://universe.roboflow.com/strawberriesssl/strawberries-re06x

Provided by a Roboflow user
License: CC BY 4.0

